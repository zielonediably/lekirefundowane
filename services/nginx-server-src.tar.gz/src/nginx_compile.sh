cd nginx-1.11.4 && make install clean
